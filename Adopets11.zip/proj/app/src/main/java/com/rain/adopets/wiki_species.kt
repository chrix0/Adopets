package com.rain.adopets

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class wiki_species : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wiki_species)
    }
}