package com.rain.adopets

const val EXTRA_PRODUCT = "com.rain.adopets.FOOD_PRODUCT"
const val CHANGE_TITLE = "com.rain.adopets.CHANGE"
const val SHOW_PRODUCT_INFO = "com.rain.adopets.PRODUCT_INFO"
const val ADD_TO_CART = "com.rain.adopets.CART"
const val CHECKOUT = "com.rain.adopets.CHECKOUT"
const val SHOW_BREED_INFO = "com.rain.adopets.BREED_INFO"
const val SHOW_ADOPT_INFO = "com.rain.adopets.ADOPT_INFO"
const val SHOW_WIKI_INFO = "com.rain.adopets.WIKI_INFO"
const val SHOW_WIKI_MORE = "com.rain.adopets.WIKI_MORE"
const val RETURN_LAST_TAB = "com.rain.adopets.LAST_TAB"
const val REQUEST_CAMERA = 111
const val REQUEST_GALLERY = 112